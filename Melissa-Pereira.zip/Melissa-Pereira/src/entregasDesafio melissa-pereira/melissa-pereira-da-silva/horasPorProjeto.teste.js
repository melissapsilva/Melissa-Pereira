const {
    calcularValorPorHora,
} = require("../../dominio/calculadora/Projeto/horasPorProjeto");

describe("Cálculo de quantidade de horas por projeto", () => {
    test("Dada uma lista de funcionalidade, valida quantas horas por projeto", () => {
        //setup
        const listaDeFuncionalidades = [
            'setup',
            'responsividade',
            'contruicao_1_pagina',
            'contruicao_1_pagina',
            'contruicao_1_pagina',
            'formulario',
            'ssr',
        ];
        
        const result = calcularHorasDeProjeto(listaDeFuncionalidades);
       
        expect(result).toBe(72);
    })
});