const { calcularPacote } = require("../../dominio/calculadora/Projeto/pacote");

describe("Retorna qual o pacote de acordo com o numero de horas", () => {
    test("Retorna se é um pacote básico", () => {
        const totalHoras = 49;
        const result = calcularPacote(totalHoras);

        expect(result).toBe("pacote_basico");
    });

    test("Retorna se é um pacote intermediario", () => {
        const totalHoras = 51;
        const result = calcularPacote(totalHoras);

        expect(result).toBe("pacote_intermediario");
    });

    test("Retorna se é um pacote premium", () => {
        const totalHoras = 101;
        const result = calcularPacote(totalHoras);

        expect(result).toBe("pacote_premium");
    });

    test("Retorna se é um pacote básico para 50h", () => {
        const totalHoras = 50;
        const result = calcularPacote(totalHoras);
        expect(result).toBe("pacote_basico");
    });

    test("Retorna se é um pacote intermediário para 100h", () => {
        const totalHoras = 100;
        const result = calcularPacote(totalHoras);
        expect(result).toBe("pacote_intermediario");
    });

    test("Retorna se é um pacote premium para 200h", () => {
        const totalHoras = 200;
        const result = calcularPacote(totalHoras);
        expect(result).toBe("pacote_premium");
    });

    test("Retorna nada para valores acima de 200", () => {
        const totalHoras = 250;
        const result = calcularPacote(totalHoras);
        expect(result).toBe();
    });

    test("Retorna nada para valores negativos", () => {
        const totalHoras = -20;
        const result = calcularPacote(totalHoras);
        expect(result).toBe();
    });
});